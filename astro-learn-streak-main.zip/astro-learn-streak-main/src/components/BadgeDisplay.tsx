
import { Badge as BadgeType } from "@/types/quiz";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Award, BadgeCheck, BadgeAlert, BadgeInfo } from "lucide-react";

interface BadgeDisplayProps {
  badge: BadgeType;
  size?: "sm" | "md" | "lg";
  showDetails?: boolean;
}

export function BadgeDisplay({ badge, size = "md", showDetails = false }: BadgeDisplayProps) {
  const getBadgeIcon = () => {
    switch (badge.icon) {
      case "award":
        return <Award className={cn("text-yellow-500", size === "sm" ? "h-4 w-4" : "h-6 w-6")} />;
      case "badge-check":
        return <BadgeCheck className={cn("text-green-500", size === "sm" ? "h-4 w-4" : "h-6 w-6")} />;
      case "badge-alert":
        return <BadgeAlert className={cn("text-blue-500", size === "sm" ? "h-4 w-4" : "h-6 w-6")} />;
      case "badge-info":
      default:
        return <BadgeInfo className={cn("text-purple-500", size === "sm" ? "h-4 w-4" : "h-6 w-6")} />;
    }
  };
  
  const getSizeClasses = () => {
    switch (size) {
      case "sm":
        return "h-12 w-12";
      case "lg":
        return "h-24 w-24";
      case "md":
      default:
        return "h-16 w-16";
    }
  };

  const isEarned = badge.earnedAt !== undefined;
  
  return (
    <div className={cn(
      "flex flex-col items-center",
      showDetails ? "gap-2" : ""
    )}>
      <div className={cn(
        "rounded-full flex items-center justify-center border-2 transition-all",
        getSizeClasses(),
        isEarned 
          ? "bg-background border-primary shadow-lg" 
          : "bg-muted/30 border-muted-foreground/20 opacity-50"
      )}>
        {getBadgeIcon()}
      </div>
      
      {showDetails && (
        <div className="text-center">
          <div className="font-medium">{badge.name}</div>
          <div className="text-xs text-muted-foreground">{badge.description}</div>
          {isEarned && (
            <Badge variant="secondary" className="mt-1">
              Earned
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}
