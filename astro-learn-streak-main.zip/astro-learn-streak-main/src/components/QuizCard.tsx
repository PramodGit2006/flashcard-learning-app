
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { QuizQuestion } from "@/types/quiz";

interface QuizCardProps {
  question: QuizQuestion;
  onAnswer: (isCorrect: boolean) => void;
}

export function QuizCard({ question, onAnswer }: QuizCardProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const handleOptionSelect = (option: string) => {
    if (isSubmitted) return;
    setSelectedOption(option);
  };
  
  const handleSubmit = () => {
    if (!selectedOption || isSubmitted) return;
    
    const isCorrect = selectedOption === question.correctAnswer;
    setIsSubmitted(true);
    
    // Delay to allow user to see result
    setTimeout(() => {
      onAnswer(isCorrect);
      setSelectedOption(null);
      setIsSubmitted(false);
    }, 1500);
  };
  
  const getOptionClass = (option: string) => {
    if (!isSubmitted || !selectedOption) {
      return selectedOption === option 
        ? "border-primary bg-primary/10" 
        : "border-border hover:border-primary/50";
    }
    
    if (option === question.correctAnswer) {
      return "border-green-500 bg-green-500/10";
    }
    
    if (selectedOption === option && option !== question.correctAnswer) {
      return "border-red-500 bg-red-500/10";
    }
    
    return "border-border opacity-50";
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6 rounded-xl border-2 border-border bg-card shadow-lg">
      <h3 className="text-xl font-medium mb-6">{question.question}</h3>
      
      <div className="space-y-3 mb-6">
        {question.options.map((option, index) => (
          <div
            key={index}
            className={cn(
              "p-4 rounded-lg border-2 cursor-pointer transition-all",
              getOptionClass(option)
            )}
            onClick={() => handleOptionSelect(option)}
          >
            <div className="flex items-center">
              <div className="h-6 w-6 rounded-full border-2 border-primary flex items-center justify-center mr-3">
                {selectedOption === option && (
                  <div className="h-3 w-3 rounded-full bg-primary" />
                )}
              </div>
              <span>{option}</span>
            </div>
          </div>
        ))}
      </div>
      
      <Button 
        onClick={handleSubmit}
        disabled={!selectedOption || isSubmitted}
        className="w-full bg-gradient-to-r from-neon-cyan to-neon-blue"
      >
        {isSubmitted ? "Next Question..." : "Submit Answer"}
      </Button>
    </div>
  );
}
