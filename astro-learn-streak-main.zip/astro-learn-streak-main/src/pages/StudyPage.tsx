
import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Check, X, ArrowLeft, FlipHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AppHeader } from "@/components/AppHeader";
import { useFlashcards, Flashcard } from "@/contexts/FlashcardContext";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function StudyPage() {
  const { deckId } = useParams<{ deckId: string }>();
  const navigate = useNavigate();
  const { 
    decks, 
    getFlashcardsByDeck, 
    markCardResult, 
    recordStudySession 
  } = useFlashcards();
  
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [studyDeck, setStudyDeck] = useState<Flashcard[]>([]);
  const [results, setResults] = useState<Record<string, boolean>>({});
  const [isCompleted, setIsCompleted] = useState(false);
  
  const deck = decks.find((d) => d.id === deckId);
  
  // Prepare study deck with shuffled cards
  useEffect(() => {
    if (deckId) {
      const cards = getFlashcardsByDeck(deckId);
      if (cards.length === 0) {
        navigate(`/deck/${deckId}`);
        toast.error("This deck has no cards to study.");
        return;
      }
      
      // Shuffle the cards
      const shuffled = [...cards].sort(() => Math.random() - 0.5);
      setStudyDeck(shuffled);
    }
  }, [deckId, getFlashcardsByDeck, navigate]);
  
  // Check if study session is complete
  useEffect(() => {
    if (studyDeck.length > 0 && currentCardIndex >= studyDeck.length) {
      setIsCompleted(true);
      
      // Record study session
      const correctAnswers = Object.values(results).filter(Boolean).length;
      recordStudySession({
        deckId: deckId || "",
        cardsStudied: studyDeck.length,
        correctAnswers,
        incorrectAnswers: studyDeck.length - correctAnswers,
      });
    }
  }, [currentCardIndex, studyDeck.length, deckId, results, recordStudySession]);
  
  const handleCardFlip = () => {
    setFlipped(!flipped);
  };
  
  const handleResult = (correct: boolean) => {
    if (currentCardIndex < studyDeck.length) {
      const currentCard = studyDeck[currentCardIndex];
      
      // Record result for current card
      setResults(prev => ({
        ...prev,
        [currentCard.id]: correct
      }));
      
      // Update card stats in flashcard context
      markCardResult(currentCard.id, correct);
      
      // Move to next card
      setCurrentCardIndex(prev => prev + 1);
      setFlipped(false);
    }
  };
  
  const handleRestart = () => {
    // Reshuffle cards
    const reshuffled = [...studyDeck].sort(() => Math.random() - 0.5);
    setStudyDeck(reshuffled);
    setCurrentCardIndex(0);
    setFlipped(false);
    setResults({});
    setIsCompleted(false);
  };
  
  const currentCard = currentCardIndex < studyDeck.length ? studyDeck[currentCardIndex] : null;
  const progress = studyDeck.length > 0 ? (currentCardIndex / studyDeck.length) * 100 : 0;
  
  if (!deck) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Deck not found</h1>
            <p className="mb-4 text-muted-foreground">The deck you're looking for doesn't exist</p>
            <Button asChild>
              <Link to="/decks">Back to Decks</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6 max-w-4xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="gap-1">
              <Link to={`/deck/${deck.id}`}>
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Deck</span>
              </Link>
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="h-8 w-8 rounded-md flex items-center justify-center"
              style={{ backgroundColor: deck.color }}
            >
              <span className="text-white font-bold text-xs">
                {deck.name.substring(0, 1).toUpperCase()}
              </span>
            </div>
            <h1 className="text-xl font-medium">{deck.name}</h1>
          </div>
        </div>
        
        {/* Progress bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2 text-sm">
            <span>{currentCardIndex} of {studyDeck.length} cards</span>
            <span>
              {progress.toFixed(0)}% complete
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
        
        {isCompleted ? (
          <div className="text-center py-12">
            <h2 className="text-3xl font-display font-bold mb-4">Study Session Complete!</h2>
            <div className="mb-8 text-lg">
              <p>You've studied all {studyDeck.length} cards in this deck.</p>
              <div className="flex justify-center gap-8 mt-6">
                <div className="text-center">
                  <div className="text-4xl font-bold text-green-500 mb-2">
                    {Object.values(results).filter(Boolean).length}
                  </div>
                  <div className="text-sm text-muted-foreground">Correct</div>
                </div>
                <div className="text-center">
                  <div className="text-4xl font-bold text-red-500 mb-2">
                    {studyDeck.length - Object.values(results).filter(Boolean).length}
                  </div>
                  <div className="text-sm text-muted-foreground">Incorrect</div>
                </div>
              </div>
            </div>
            <div className="flex justify-center gap-4">
              <Button 
                onClick={handleRestart}
                className="bg-gradient-to-r from-neon-cyan to-neon-blue"
              >
                Study Again
              </Button>
              <Button variant="outline" asChild>
                <Link to={`/deck/${deck.id}`}>
                  Return to Deck
                </Link>
              </Button>
            </div>
          </div>
        ) : (
          currentCard && (
            <div className="mb-8">
              <div 
                className="w-full h-[400px] mx-auto cursor-pointer perspective-1000"
                onClick={handleCardFlip}
              >
                <div className={cn(
                  "w-full h-full transition-transform duration-500 transform-style-3d",
                  flipped && "rotate-y-180"
                )}>
                  {/* Front of card (Question) */}
                  <div className={cn(
                    "absolute w-full h-full rounded-xl p-8 flex flex-col backface-hidden",
                    "bg-card border-2 border-border shadow-lg"
                  )}>
                    <div className="flex justify-end mb-2">
                      <FlipHorizontal className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground mb-4">QUESTION</div>
                        <h3 className="text-2xl font-medium">{currentCard.question}</h3>
                      </div>
                    </div>
                    <div className="text-center text-muted-foreground text-sm mt-4">
                      Click to see answer
                    </div>
                  </div>
                  
                  {/* Back of card (Answer) */}
                  <div className={cn(
                    "absolute w-full h-full rounded-xl p-8 flex flex-col backface-hidden rotate-y-180",
                    "bg-card border-2 border-border shadow-lg"
                  )}>
                    <div className="flex justify-end mb-2">
                      <FlipHorizontal className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground mb-4">ANSWER</div>
                        <h3 className="text-2xl font-medium">{currentCard.answer}</h3>
                      </div>
                    </div>
                    
                    <div className="flex justify-center gap-4 mt-4">
                      <Button 
                        className="bg-red-500 hover:bg-red-600 text-white" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleResult(false);
                        }}
                      >
                        <X className="mr-2 h-4 w-4" />
                        Incorrect
                      </Button>
                      <Button 
                        className="bg-green-500 hover:bg-green-600 text-white" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleResult(true);
                        }}
                      >
                        <Check className="mr-2 h-4 w-4" />
                        Correct
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-center text-sm text-muted-foreground mt-4">
                Card {currentCardIndex + 1} of {studyDeck.length}
              </div>
            </div>
          )
        )}
      </main>
    </div>
  );
}
