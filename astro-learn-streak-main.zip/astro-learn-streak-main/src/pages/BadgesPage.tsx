
import { AppHeader } from "@/components/AppHeader";
import { useAuth } from "@/contexts/AuthContext";
import { useFlashcards } from "@/contexts/FlashcardContext";
import { BadgeDisplay } from "@/components/BadgeDisplay";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function BadgesPage() {
  const { currentUser } = useAuth();
  const { badges } = useFlashcards();
  
  const earnedBadges = badges.filter(b => b.earnedAt !== undefined);
  const unearnedBadges = badges.filter(b => b.earnedAt === undefined);
  
  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Please log in</h1>
            <p className="mb-4 text-muted-foreground">You need to be logged in to view your badges</p>
            <Button asChild>
              <Link to="/login">Log In</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6">
        <h1 className="text-3xl font-display font-bold mb-8">Your Achievements</h1>
        
        {earnedBadges.length === 0 ? (
          <div className="text-center py-12 border border-dashed rounded-lg">
            <h2 className="text-xl font-semibold mb-2">No badges earned yet</h2>
            <p className="text-muted-foreground mb-4">
              Complete quizzes and meet goals to earn badges
            </p>
            <Button asChild>
              <Link to="/decks">Start Learning</Link>
            </Button>
          </div>
        ) : (
          <div className="mb-12">
            <h2 className="text-xl font-semibold mb-6">Earned Badges</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {earnedBadges.map(badge => (
                <div key={badge.id} className="flex flex-col items-center">
                  <BadgeDisplay badge={badge} size="lg" showDetails />
                  <div className="text-xs text-muted-foreground mt-2">
                    Earned on {new Date(badge.earnedAt!).toLocaleDateString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {unearnedBadges.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-6">Badges to Earn</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {unearnedBadges.map(badge => (
                <BadgeDisplay key={badge.id} badge={badge} size="md" showDetails />
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
