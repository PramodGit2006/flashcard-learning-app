
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { AppHeader } from "@/components/AppHeader";

export default function Index() {
  const { currentUser } = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1">
        {/* Hero section */}
        <section className="py-16 md:py-24 bg-gradient-to-b from-background to-muted/20">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center text-center space-y-8">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-neon-cyan to-neon-blue opacity-10 blur-[100px] rounded-full pointer-events-none" />
                <h1 className="font-display font-bold text-4xl sm:text-5xl md:text-6xl lg:text-7xl bg-clip-text text-transparent bg-gradient-to-r from-neon-cyan via-neon-blue to-neon-purple">
                  Master Any Topic with FlashMaster
                </h1>
              </div>
              
              <p className="max-w-[700px] text-lg md:text-xl text-muted-foreground">
                Accelerate your learning with our futuristic spaced repetition flashcard system. 
                Create decks, track progress, and build knowledge that lasts.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                {currentUser ? (
                  <Button size="lg" asChild className="bg-gradient-to-r from-neon-cyan to-neon-blue text-white">
                    <Link to="/decks">My Flashcards</Link>
                  </Button>
                ) : (
                  <>
                    <Button size="lg" asChild className="bg-gradient-to-r from-neon-cyan to-neon-blue text-white">
                      <Link to="/register">Get Started</Link>
                    </Button>
                    <Button size="lg" variant="outline" asChild>
                      <Link to="/login">Login</Link>
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Features section */}
        <section className="py-16 md:py-24">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-display font-bold text-center mb-12">
              Features that <span className="bg-clip-text text-transparent bg-gradient-to-r from-neon-cyan to-neon-purple">enhance learning</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-2xl">🔄</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Spaced Repetition</h3>
                <p className="text-muted-foreground">
                  Our algorithm optimizes when you review cards, helping you remember information long-term.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-2xl">📊</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Progress Analytics</h3>
                <p className="text-muted-foreground">
                  Track your learning with detailed charts and statistics that show your improvements over time.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-2xl">🔥</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Daily Streaks</h3>
                <p className="text-muted-foreground">
                  Stay motivated with daily streaks and achievements that reward consistent learning.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-2xl">🏆</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Achievement Badges</h3>
                <p className="text-muted-foreground">
                  Earn badges as you reach milestones and accomplish learning goals.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-2xl">🌙</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Night Mode</h3>
                <p className="text-muted-foreground">
                  Study comfortably day or night with our customizable theme options.
                </p>
              </div>
              
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card hover:shadow-lg transition-shadow">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <span className="text-2xl">📱</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Responsive Design</h3>
                <p className="text-muted-foreground">
                  Learn anywhere with a fully responsive experience that works on all your devices.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA section */}
        <section className="py-16 md:py-24 bg-gradient-to-t from-background to-muted/20">
          <div className="container px-4 md:px-6 text-center">
            <div className="max-w-[700px] mx-auto space-y-6">
              <h2 className="text-3xl md:text-4xl font-display font-bold">
                Ready to boost your learning?
              </h2>
              <p className="text-lg text-muted-foreground">
                Join FlashMaster today and transform how you learn.
              </p>
              {currentUser ? (
                <Button size="lg" asChild className="bg-gradient-to-r from-neon-cyan to-neon-purple text-white">
                  <Link to="/decks">Get Started</Link>
                </Button>
              ) : (
                <Button size="lg" asChild className="bg-gradient-to-r from-neon-cyan to-neon-purple text-white">
                  <Link to="/register">Create Free Account</Link>
                </Button>
              )}
            </div>
          </div>
        </section>
      </main>
      
      <footer className="border-t py-8">
        <div className="container px-4 md:px-6 text-center">
          <p className="text-sm text-muted-foreground">
            © 2025 FlashMaster. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
