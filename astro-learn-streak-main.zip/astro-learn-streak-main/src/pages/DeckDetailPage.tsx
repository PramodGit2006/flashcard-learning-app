import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { Edit, Trash2, ArrowLeft, Plus, BookOpen, FlipHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { AlertDialog, AlertDialogTrigger, AlertDialogContent, AlertDialogHeader, AlertDialogFooter, AlertDialogTitle, AlertDialogDescription, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/components/ui/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { AppHeader } from "@/components/AppHeader";
import { useFlashcards, Flashcard, Deck } from "@/contexts/FlashcardContext";
import { cn } from "@/lib/utils";

// Define the Flashcard form schema
const flashcardSchema = z.object({
  question: z.string().min(3, {
    message: "Question must be at least 3 characters.",
  }),
  answer: z.string().min(3, {
    message: "Answer must be at least 3 characters.",
  }),
});

export default function DeckDetailPage() {
  const { deckId } = useParams<{ deckId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { 
    decks, 
    flashcards, 
    getFlashcardsByDeck, 
    updateDeck, 
    deleteDeck, 
    createFlashcard, 
    updateFlashcard, 
    deleteFlashcard 
  } = useFlashcards();
  
  const [isEditMode, setIsEditMode] = useState(false);
  const [deckName, setDeckName] = useState("");
  const [deckDescription, setDeckDescription] = useState("");
  const [newCardVisible, setNewCardVisible] = useState(false);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [flippedCards, setFlippedCards] = useState<Record<string, boolean>>({});
  
  const deck = decks.find((d) => d.id === deckId);
  const deckFlashcards = getFlashcardsByDeck(deckId || "");
  
  useEffect(() => {
    if (deck) {
      setDeckName(deck.name);
      setDeckDescription(deck.description);
    }
  }, [deck]);
  
  const deckForm = useForm<z.infer<typeof flashcardSchema>>({
    resolver: zodResolver(flashcardSchema),
    defaultValues: {
      question: "",
      answer: "",
    },
  });
  
  const { handleSubmit, reset } = deckForm;
  
  const onSubmit = async (values: z.infer<typeof flashcardSchema>) => {
    if (!deckId) return;
    
    if (editingCardId) {
      // Update existing card
      updateFlashcard({
        id: editingCardId,
        deckId: deckId,
        question: values.question,
        answer: values.answer,
        lastReviewed: Date.now(),
        correctCount: 0,
        incorrectCount: 0
      });
      toast({
        title: "Flashcard updated successfully!",
      });
    } else {
      // Create new card
      createFlashcard({
        deckId: deckId,
        question: values.question,
        answer: values.answer
      });
      toast({
        title: "Flashcard created successfully!",
      });
    }
    
    setNewCardVisible(false);
    setEditingCardId(null);
    reset({ question: "", answer: "" });
  };
  
  const handleDeckUpdate = () => {
    if (!deck) return;
    
    updateDeck({
      ...deck,
      name: deckName,
      description: deckDescription
    });
    setIsEditMode(false);
    toast({
      title: "Deck updated successfully!",
    });
  };
  
  const handleDeckDelete = () => {
    if (!deckId) return;
    
    deleteDeck(deckId);
    navigate("/decks");
    toast({
      title: "Deck deleted successfully!",
    });
  };
  
  const handleEditCard = (card: Flashcard) => {
    setEditingCardId(card.id);
    setNewCardVisible(true);
    deckForm.setValue("question", card.question);
    deckForm.setValue("answer", card.answer);
  };
  
  const handleDeleteCard = (cardId: string) => {
    deleteFlashcard(cardId);
    toast({
      title: "Flashcard deleted successfully!",
    });
  };

  const handleCardFlip = (cardId: string) => {
    setFlippedCards(prev => ({
      ...prev,
      [cardId]: !prev[cardId]
    }));
  };

  if (!deck) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Deck not found</h1>
            <p className="mb-4 text-muted-foreground">The deck you're looking for doesn't exist</p>
            <Button asChild>
              <Link to="/decks">Back to Decks</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="gap-1">
              <Link to="/decks">
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Decks</span>
              </Link>
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="h-8 w-8 rounded-md flex items-center justify-center"
              style={{ backgroundColor: deck.color }}
            >
              <span className="text-white font-bold text-xs">
                {deck.name.substring(0, 1).toUpperCase()}
              </span>
            </div>
            <h1 className="text-xl font-medium">{deck.name}</h1>
          </div>
        </div>
        
        {/* Deck edit form */}
        {isEditMode ? (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Edit Deck</CardTitle>
              <CardDescription>Update your deck details here.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Deck Name</Label>
                <Input 
                  id="name" 
                  value={deckName} 
                  onChange={(e) => setDeckName(e.target.value)} 
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={deckDescription}
                  onChange={(e) => setDeckDescription(e.target.value)}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setIsEditMode(false)}>
                Cancel
              </Button>
              <Button onClick={handleDeckUpdate}>Update Deck</Button>
            </CardFooter>
          </Card>
        ) : (
          <div className="flex justify-between items-center mb-4">
            <p className="text-muted-foreground">{deckDescription}</p>
            <div>
              <Button size="sm" variant="outline" onClick={() => setIsEditMode(true)}>
                <Edit className="h-4 w-4 mr-2" />
                Edit Deck
              </Button>
            </div>
          </div>
        )}
        
        {/* Deck actions */}
        <div className="flex flex-wrap gap-4 mb-8">
          <Button 
            asChild 
            className="bg-gradient-to-r from-neon-cyan to-neon-blue"
          >
            <Link to={`/study/${deck.id}`}>
              <BookOpen className="mr-2 h-4 w-4" />
              Study Deck
            </Link>
          </Button>
          
          {/* Add the Quiz button here */}
          <Button asChild>
            <Link to={`/quiz/${deck.id}`}>
              Take Quiz
            </Link>
          </Button>
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Deck
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete your deck and remove all associated flashcards from our servers.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeckDelete}>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
        
        {/* Flashcard creation form */}
        <div className="mb-4 flex justify-between items-center">
          <h2 className="text-2xl font-medium">Flashcards</h2>
          <Button size="sm" onClick={() => {
            setNewCardVisible(!newCardVisible);
            setEditingCardId(null);
            deckForm.reset();
          }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Flashcard
          </Button>
        </div>
        
        {newCardVisible && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>{editingCardId ? "Edit Flashcard" : "New Flashcard"}</CardTitle>
              <CardDescription>Add a new flashcard to this deck.</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...deckForm}>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={deckForm.control}
                    name="question"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Question</FormLabel>
                        <FormControl>
                          <Input placeholder="What is the capital of France?" {...field} />
                        </FormControl>
                        <FormDescription>Enter the question for your flashcard.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={deckForm.control}
                    name="answer"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Answer</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Paris" {...field} />
                        </FormControl>
                        <FormDescription>Enter the answer to the question.</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end gap-2">
                    <Button variant="secondary" type="button" onClick={() => {
                      setNewCardVisible(false);
                      setEditingCardId(null);
                      deckForm.reset();
                    }}>
                      Cancel
                    </Button>
                    <Button type="submit">
                      {editingCardId ? "Update Flashcard" : "Create Flashcard"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        )}
        
        {/* Flashcard list */}
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
          {deckFlashcards.map((card) => (
            <div 
              key={card.id}
              className="relative h-[200px] perspective-1000"
              onClick={() => handleCardFlip(card.id)}
            >
              <div className={cn(
                "h-full w-full transition-transform duration-500 transform-style-3d cursor-pointer",
                flippedCards[card.id] && "rotate-y-180"
              )}>
                {/* Front side (Question) */}
                <Card className="absolute h-full w-full backface-hidden">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">{card.question}</CardTitle>
                      <FlipHorizontal className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <CardDescription>Click to flip card</CardDescription>
                  </CardHeader>
                </Card>
                
                {/* Back side (Answer) */}
                <Card className="absolute h-full w-full backface-hidden rotate-y-180">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">Answer</CardTitle>
                      <FlipHorizontal className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p>{card.answer}</p>
                  </CardContent>
                </Card>
              </div>
              
              {/* Card actions - outside the flip container so they don't flip */}
              <div className="absolute bottom-2 right-2 z-10 flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleEditCard(card);
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button 
                  size="sm" 
                  variant="destructive" 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteCard(card.id);
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
        
        {deckFlashcards.length === 0 && (
          <div className="text-center p-6">
            <p className="text-muted-foreground">No flashcards in this deck yet. Add some cards to start studying!</p>
          </div>
        )}
      </main>
    </div>
  );
}
