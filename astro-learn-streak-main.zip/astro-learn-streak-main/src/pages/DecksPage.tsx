
import { useState } from "react";
import { Link } from "react-router-dom";
import { PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AppHeader } from "@/components/AppHeader";
import { useAuth } from "@/contexts/AuthContext";
import { useFlashcards, Deck } from "@/contexts/FlashcardContext";
import { useForm } from "react-hook-form";
import { formatDistanceToNow } from "date-fns";

export default function DecksPage() {
  const { currentUser } = useAuth();
  const { decks, createDeck, getFlashcardsByDeck } = useFlashcards();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedColor, setSelectedColor] = useState("#3B82F6"); // Default color (blue)
  
  const colors = [
    "#EF4444", // red
    "#F59E0B", // amber
    "#10B981", // emerald
    "#3B82F6", // blue
    "#8B5CF6", // violet
    "#EC4899", // pink
  ];

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const onSubmit = (data: { name: string; description: string }) => {
    if (currentUser) {
      createDeck({
        name: data.name,
        description: data.description,
        userId: currentUser.id,
        lastStudied: null,
        color: selectedColor,
      });
      reset();
      setSelectedColor("#3B82F6"); // Reset color
      setIsDialogOpen(false);
    }
  };

  const handleDialogChange = (open: boolean) => {
    setIsDialogOpen(open);
    if (!open) {
      reset();
      setSelectedColor("#3B82F6");
    }
  };

  const getLastStudiedText = (lastStudied: number | null) => {
    if (!lastStudied) return "Never studied";
    return `${formatDistanceToNow(lastStudied)} ago`;
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Please log in</h1>
            <p className="mb-4 text-muted-foreground">You need to be logged in to view your decks</p>
            <Button asChild>
              <Link to="/login">Log In</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-display font-bold">My Flashcard Decks</h1>
          
          <Dialog open={isDialogOpen} onOpenChange={handleDialogChange}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-neon-cyan to-neon-blue">
                <PlusCircle className="mr-2 h-4 w-4" />
                New Deck
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <form onSubmit={handleSubmit(onSubmit)}>
                <DialogHeader>
                  <DialogTitle>Create New Deck</DialogTitle>
                  <DialogDescription>
                    Create a new flashcard deck for your study materials.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Deck Name</Label>
                    <Input
                      id="name"
                      placeholder="e.g., Spanish Vocabulary"
                      {...register("name", { required: "Deck name is required" })}
                      className={errors.name ? "border-destructive" : ""}
                    />
                    {errors.name && (
                      <p className="text-sm text-destructive">{errors.name.message}</p>
                    )}
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      placeholder="What's this deck about?"
                      {...register("description")}
                      className="resize-none"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Deck Color</Label>
                    <div className="flex gap-2">
                      {colors.map((color) => (
                        <div
                          key={color}
                          className={`h-8 w-8 rounded-full cursor-pointer transition-all ${
                            selectedColor === color 
                              ? "ring-2 ring-primary ring-offset-2" 
                              : "hover:scale-110"
                          }`}
                          style={{ backgroundColor: color }}
                          onClick={() => setSelectedColor(color)}
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button type="submit">Create Deck</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
        
        {decks.length === 0 ? (
          <div className="text-center p-12 border border-dashed rounded-lg">
            <h2 className="text-xl font-semibold mb-2">No decks yet</h2>
            <p className="text-muted-foreground mb-4">
              Create your first flashcard deck to start studying
            </p>
            <Button 
              onClick={() => setIsDialogOpen(true)}
              className="bg-gradient-to-r from-neon-cyan to-neon-blue"
            >
              <PlusCircle className="mr-2 h-4 w-4" />
              Create First Deck
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {decks.map((deck) => {
              const cardCount = getFlashcardsByDeck(deck.id).length;
              return (
                <Link 
                  key={deck.id} 
                  to={`/deck/${deck.id}`}
                  className="group"
                >
                  <div 
                    className="h-full border rounded-lg p-6 transition-all bg-card hover:shadow-lg group-hover:border-primary"
                  >
                    <div className="flex items-center mb-4">
                      <div 
                        className="h-12 w-12 rounded-md flex items-center justify-center mr-4"
                        style={{ backgroundColor: deck.color }}
                      >
                        <span className="text-white font-bold text-lg">
                          {deck.name.substring(0, 1).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <h2 className="font-semibold text-lg line-clamp-1">{deck.name}</h2>
                        <p className="text-sm text-muted-foreground">
                          {cardCount} {cardCount === 1 ? "card" : "cards"}
                        </p>
                      </div>
                    </div>
                    
                    {deck.description && (
                      <p className="text-sm mb-4 line-clamp-2">{deck.description}</p>
                    )}
                    
                    <div className="mt-auto pt-2 border-t text-xs text-muted-foreground">
                      Last studied: {getLastStudiedText(deck.lastStudied)}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
