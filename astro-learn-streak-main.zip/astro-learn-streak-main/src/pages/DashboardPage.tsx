
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Label } from "recharts";
import { format, subDays, isSameDay } from "date-fns";
import { AppHeader } from "@/components/AppHeader";
import { useAuth } from "@/contexts/AuthContext";
import { useFlashcards, StudySession, Deck } from "@/contexts/FlashcardContext";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DashboardPage() {
  const { currentUser } = useAuth();
  const { decks, flashcards, sessions, streak } = useFlashcards();
  const [activityData, setActivityData] = useState<any[]>([]);
  const [performanceData, setPerformanceData] = useState<any[]>([]);
  const [deckStats, setDeckStats] = useState<any[]>([]);

  // Calculate study stats
  useEffect(() => {
    // Prepare activity data (last 14 days)
    const days = 14;
    const activity = Array.from({ length: days }).map((_, i) => {
      const date = subDays(new Date(), days - 1 - i);
      const dayFormat = format(date, "MMM d");
      
      // Find sessions for this day
      const daySessions = sessions.filter(session => 
        isSameDay(new Date(session.date), date)
      );
      
      // Calculate cards studied
      const cardsStudied = daySessions.reduce((sum, session) => sum + session.cardsStudied, 0);
      
      return {
        day: dayFormat,
        date: date.getTime(),
        cards: cardsStudied,
      };
    });
    
    setActivityData(activity);
    
    // Prepare performance data
    if (sessions.length > 0) {
      // Last 10 sessions or less
      const recentSessions = [...sessions]
        .sort((a, b) => b.date - a.date)
        .slice(0, 10);
      
      const performance = recentSessions.map(session => {
        const date = new Date(session.date);
        return {
          date: format(date, "MMM d"),
          correct: session.correctAnswers,
          incorrect: session.incorrectAnswers,
          accuracy: session.cardsStudied > 0 
            ? Math.round((session.correctAnswers / session.cardsStudied) * 100) 
            : 0
        };
      }).reverse();
      
      setPerformanceData(performance);
    }
    
    // Prepare deck stats
    const stats = decks.map(deck => {
      const deckCards = flashcards.filter(card => card.deckId === deck.id);
      const totalCards = deckCards.length;
      const reviewedCards = deckCards.filter(card => card.lastReviewed !== null).length;
      const mastered = deckCards.filter(card => 
        card.correctCount > 0 && 
        card.correctCount / (card.correctCount + card.incorrectCount) >= 0.8
      ).length;
      
      return {
        id: deck.id,
        name: deck.name,
        color: deck.color,
        totalCards,
        reviewedCards,
        masteredCards: mastered,
        masteryPercentage: totalCards > 0 ? Math.round((mastered / totalCards) * 100) : 0
      };
    });
    
    setDeckStats(stats);
  }, [decks, flashcards, sessions]);
  
  // Helper for calculating total cards, reviewed, etc.
  const getTotals = () => {
    const totalCards = flashcards.length;
    const reviewedCards = flashcards.filter(card => card.lastReviewed !== null).length;
    const totalReviews = flashcards.reduce((sum, card) => 
      sum + card.correctCount + card.incorrectCount, 0
    );
    
    return {
      totalCards,
      reviewedCards,
      reviewProgress: totalCards > 0 ? Math.round((reviewedCards / totalCards) * 100) : 0,
      totalReviews
    };
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Please log in</h1>
            <p className="mb-4 text-muted-foreground">You need to be logged in to view your dashboard</p>
            <Button asChild>
              <Link to="/login">Log In</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const totals = getTotals();

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6">
        <h1 className="text-3xl font-display font-bold mb-8">Learning Dashboard</h1>
        
        {/* Overview cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Card count stat */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Flashcards
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totals.totalCards}</div>
            </CardContent>
          </Card>
          
          {/* Decks stat */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Decks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{decks.length}</div>
            </CardContent>
          </Card>
          
          {/* Review count stat */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Reviews
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totals.totalReviews}</div>
            </CardContent>
          </Card>
          
          {/* Streak stat */}
          <Card className="bg-gradient-to-br from-background to-muted/30 border-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Current Streak
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center">
              <div className="text-3xl font-bold mr-2">{streak}</div>
              <div className="text-2xl">🔥</div>
            </CardContent>
            <CardFooter className="pt-0 text-xs text-muted-foreground">
              days in a row
            </CardFooter>
          </Card>
        </div>
        
        {/* Main dashboard tabs */}
        <Tabs defaultValue="progress" className="w-full">
          <TabsList>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="decks">Decks</TabsTrigger>
          </TabsList>
          
          {/* Progress tab */}
          <TabsContent value="progress" className="space-y-4 mt-6">
            {sessions.length === 0 ? (
              <div className="text-center p-12 border border-dashed rounded-lg">
                <h2 className="text-xl font-semibold mb-2">No study sessions yet</h2>
                <p className="text-muted-foreground mb-4">
                  Start studying to see your performance stats
                </p>
                <Button asChild>
                  <Link to="/decks">Go to Decks</Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Performance chart */}
                <Card className="col-span-1 lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Learning Performance</CardTitle>
                    <CardDescription>
                      Your answer accuracy in recent study sessions
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={performanceData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#888" opacity={0.2} />
                        <XAxis dataKey="date" stroke="#888" />
                        <YAxis stroke="#888">
                          <Label
                            position="left"
                            style={{ textAnchor: "middle", fill: "#888" }}
                            value="Accuracy (%)"
                            angle={-90}
                          />
                        </YAxis>
                        <Tooltip />
                        <Legend />
                        <Line
                          type="monotone"
                          name="Accuracy %"
                          dataKey="accuracy"
                          stroke="#00FFFF"
                          activeDot={{ r: 8 }}
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                
                {/* Correct vs Incorrect chart */}
                <Card>
                  <CardHeader>
                    <CardTitle>Correct vs Incorrect</CardTitle>
                    <CardDescription>
                      Breakdown of your recent answers
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={performanceData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#888" opacity={0.2} />
                        <XAxis dataKey="date" stroke="#888" />
                        <YAxis stroke="#888" />
                        <Tooltip />
                        <Legend />
                        <Bar name="Correct" dataKey="correct" fill="#10B981" />
                        <Bar name="Incorrect" dataKey="incorrect" fill="#EF4444" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
                
                {/* Progress stats */}
                <Card>
                  <CardHeader>
                    <CardTitle>Learning Progress</CardTitle>
                    <CardDescription>
                      Your mastery across all flashcards
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-8">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <div>Cards Reviewed</div>
                          <div className="font-medium">{totals.reviewedCards} / {totals.totalCards}</div>
                        </div>
                        <Progress value={totals.reviewProgress} className="h-2" />
                      </div>
                      
                      {deckStats.slice(0, 3).map((deck) => (
                        <div key={deck.id} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center">
                              <div 
                                className="h-3 w-3 rounded-full mr-2"
                                style={{ backgroundColor: deck.color }}
                              />
                              <span>{deck.name}</span>
                            </div>
                            <div className="font-medium">{deck.masteryPercentage}% mastered</div>
                          </div>
                          <Progress value={deck.masteryPercentage} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </TabsContent>
          
          {/* Activity tab */}
          <TabsContent value="activity" className="space-y-4 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Daily Study Activity</CardTitle>
                <CardDescription>
                  Number of cards studied in the last 14 days
                </CardDescription>
              </CardHeader>
              <CardContent className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={activityData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#888" opacity={0.2} />
                    <XAxis dataKey="day" stroke="#888" />
                    <YAxis stroke="#888" />
                    <Tooltip />
                    <Legend />
                    <Bar 
                      name="Cards Studied" 
                      dataKey="cards" 
                      fill="url(#colorGradient)" 
                      radius={[4, 4, 0, 0]}
                    />
                    <defs>
                      <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#00FFFF" />
                        <stop offset="100%" stopColor="#8A2BE2" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Decks tab */}
          <TabsContent value="decks" className="space-y-4 mt-6">
            {decks.length === 0 ? (
              <div className="text-center p-12 border border-dashed rounded-lg">
                <h2 className="text-xl font-semibold mb-2">No decks yet</h2>
                <p className="text-muted-foreground mb-4">
                  Create your first flashcard deck to track stats
                </p>
                <Button asChild>
                  <Link to="/decks">Create Deck</Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {deckStats.map((deck) => (
                  <Card key={deck.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center">
                        <div 
                          className="h-8 w-8 rounded-md flex items-center justify-center mr-4"
                          style={{ backgroundColor: deck.color }}
                        >
                          <span className="text-white font-bold text-xs">
                            {deck.name.substring(0, 1).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <CardTitle className="text-lg">{deck.name}</CardTitle>
                          <CardDescription>
                            {deck.totalCards} cards • {deck.reviewedCards} reviewed
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Mastery</span>
                          <span className="font-medium">
                            {deck.masteredCards} / {deck.totalCards} cards
                          </span>
                        </div>
                        <Progress value={deck.masteryPercentage} className="h-2" />
                      </div>
                    </CardContent>
                    <CardFooter className="border-t pt-4">
                      <Button size="sm" variant="outline" asChild className="ml-auto">
                        <Link to={`/deck/${deck.id}`}>
                          View Deck
                        </Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
