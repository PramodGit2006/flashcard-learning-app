
import { AppHeader } from "@/components/AppHeader";
import { useAuth } from "@/contexts/AuthContext";
import { useFlashcards } from "@/contexts/FlashcardContext";
import { BadgeDisplay } from "@/components/BadgeDisplay";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Trophy, Medal, Award } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function LeaderboardPage() {
  const { currentUser } = useAuth();
  const { getLeaderboard, badges, quizResults } = useFlashcards();
  
  // In a real app, this would show multiple users
  const leaderboard = getLeaderboard();
  
  // Get user's earned badges
  const userBadges = badges.filter(badge => badge.earnedAt !== undefined);
  
  // Get user's recent quiz results
  const recentQuizzes = [...quizResults]
    .sort((a, b) => b.date - a.date)
    .slice(0, 5);
  
  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Please log in</h1>
            <p className="mb-4 text-muted-foreground">You need to be logged in to view the leaderboard</p>
            <Button asChild>
              <Link to="/login">Log In</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6">
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <h1 className="text-3xl font-display font-bold">Leaderboard</h1>
          <div className="flex gap-4 mt-4 sm:mt-0">
            <Button variant="outline" asChild>
              <Link to="/badges">
                View All Badges
              </Link>
            </Button>
            <Button asChild className="bg-gradient-to-r from-neon-cyan to-neon-blue">
              <Link to="/decks">
                Study More
              </Link>
            </Button>
          </div>
        </div>
        
        {/* Top players section */}
        <div className="mb-12">
          <h2 className="text-xl font-semibold mb-6">Top Players</h2>
          
          {leaderboard.length === 0 ? (
            <div className="text-center py-12 border border-dashed rounded-lg">
              <h2 className="text-xl font-semibold mb-2">No scores yet</h2>
              <p className="text-muted-foreground mb-4">
                Complete quizzes to appear on the leaderboard
              </p>
              <Button asChild>
                <Link to="/decks">Start Learning</Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {leaderboard.map((user, index) => (
                <div 
                  key={user.userId}
                  className="rounded-lg border bg-card text-card-foreground shadow-lg p-6"
                >
                  <div className="flex items-center gap-4">
                    {index === 0 && (
                      <Trophy className="h-10 w-10 text-yellow-500" />
                    )}
                    {index === 1 && (
                      <Medal className="h-10 w-10 text-gray-400" />
                    )}
                    {index === 2 && (
                      <Award className="h-10 w-10 text-amber-700" />
                    )}
                    
                    <div>
                      <h3 className="text-lg font-semibold">
                        {currentUser?.name || currentUser?.email || "You"}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {user.badges} badges earned
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-4 text-center">
                    <div className="text-3xl font-bold">{user.score}</div>
                    <div className="text-sm text-muted-foreground">Total Score</div>
                  </div>
                  
                  {userBadges.length > 0 && (
                    <div className="mt-4 flex justify-center gap-2">
                      {userBadges.slice(0, 3).map(badge => (
                        <BadgeDisplay key={badge.id} badge={badge} size="sm" />
                      ))}
                      {userBadges.length > 3 && (
                        <Badge variant="secondary">+{userBadges.length - 3} more</Badge>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Recent quizzes section */}
        <div>
          <h2 className="text-xl font-semibold mb-6">Recent Quiz Results</h2>
          
          {recentQuizzes.length === 0 ? (
            <div className="text-center py-8 border border-dashed rounded-lg">
              <p className="text-muted-foreground">
                No quiz results yet. Take a quiz to see your results here.
              </p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-lg border">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium">Date</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Deck</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Score</th>
                    <th className="px-4 py-3 text-left text-sm font-medium">Accuracy</th>
                  </tr>
                </thead>
                <tbody>
                  {recentQuizzes.map(quiz => {
                    const deck = quiz.deckId ? 
                      useFlashcards().decks.find(d => d.id === quiz.deckId)?.name || "Unknown" : 
                      "Unknown";
                      
                    const accuracy = quiz.totalQuestions > 0 
                      ? Math.round((quiz.score / quiz.totalQuestions) * 100) 
                      : 0;
                      
                    return (
                      <tr key={quiz.id} className="border-t">
                        <td className="px-4 py-3 text-sm">
                          {new Date(quiz.date).toLocaleDateString()}
                        </td>
                        <td className="px-4 py-3 text-sm">{deck}</td>
                        <td className="px-4 py-3 text-sm">
                          {quiz.score}/{quiz.totalQuestions}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <Badge 
                            className={
                              accuracy >= 80 ? "bg-green-500" : 
                              accuracy >= 60 ? "bg-yellow-500" : 
                              "bg-red-500"
                            }
                          >
                            {accuracy}%
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
