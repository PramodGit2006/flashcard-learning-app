
import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AppHeader } from "@/components/AppHeader";
import { useFlashcards } from "@/contexts/FlashcardContext";
import { useAuth } from "@/contexts/AuthContext";
import { QuizQuestion } from "@/types/quiz";
import { QuizCard } from "@/components/QuizCard";
import { toast } from "sonner";
import { BadgeDisplay } from "@/components/BadgeDisplay";

export default function QuizPage() {
  const { deckId } = useParams<{ deckId: string }>();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { decks, createQuiz, saveQuizResult, checkAndAwardBadges } = useFlashcards();
  
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [earnedBadges, setEarnedBadges] = useState<any[]>([]);
  
  const deck = decks.find((d) => d.id === deckId);
  
  useEffect(() => {
    if (deckId && !questions.length) {
      const newQuiz = createQuiz(deckId);
      if (newQuiz.length > 0) {
        setQuestions(newQuiz);
      } else {
        // Not enough cards for a quiz
        navigate(`/deck/${deckId}`);
      }
    }
  }, [deckId, createQuiz, navigate, questions.length]);
  
  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(prev => prev + 1);
    }
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      completeQuiz();
    }
  };
  
  const completeQuiz = () => {
    if (!currentUser || !deckId) return;
    
    // Save quiz result
    saveQuizResult({
      userId: currentUser.id,
      deckId,
      score,
      totalQuestions: questions.length
    });
    
    // Check for new badges
    const newBadges = checkAndAwardBadges(currentUser.id);
    setEarnedBadges(newBadges);
    
    setQuizCompleted(true);
  };
  
  const handleRetakeQuiz = () => {
    if (deckId) {
      const newQuiz = createQuiz(deckId);
      if (newQuiz.length > 0) {
        setQuestions(newQuiz);
        setCurrentQuestionIndex(0);
        setScore(0);
        setQuizCompleted(false);
        setEarnedBadges([]);
      }
    }
  };
  
  const currentQuestion = questions[currentQuestionIndex];
  const progress = questions.length > 0 
    ? ((currentQuestionIndex) / questions.length) * 100
    : 0;

  if (!deck) {
    return (
      <div className="min-h-screen flex flex-col">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center p-6">
            <h1 className="text-2xl font-bold mb-2">Deck not found</h1>
            <p className="mb-4 text-muted-foreground">The deck you're looking for doesn't exist</p>
            <Button asChild>
              <Link to="/decks">Back to Decks</Link>
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <AppHeader />
      
      <main className="flex-1 container py-8 px-4 md:px-6 max-w-4xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild className="gap-1">
              <Link to={`/deck/${deck.id}`}>
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Deck</span>
              </Link>
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <div 
              className="h-8 w-8 rounded-md flex items-center justify-center"
              style={{ backgroundColor: deck.color }}
            >
              <span className="text-white font-bold text-xs">
                {deck.name.substring(0, 1).toUpperCase()}
              </span>
            </div>
            <h1 className="text-xl font-medium">{deck.name} Quiz</h1>
          </div>
        </div>
        
        {/* Progress bar */}
        {!quizCompleted && questions.length > 0 && (
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2 text-sm">
              <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
              <span>Score: {score}/{currentQuestionIndex}</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}
        
        {quizCompleted ? (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gradient-to-br from-neon-cyan to-neon-blue rounded-full mx-auto mb-6 flex items-center justify-center">
              <Trophy className="h-10 w-10 text-white" />
            </div>
            
            <h2 className="text-3xl font-display font-bold mb-4">Quiz Completed!</h2>
            
            <div className="mb-6 text-lg">
              <p>Your final score: <span className="font-semibold">{score}/{questions.length}</span></p>
              <p className="text-muted-foreground mt-1">
                {score === questions.length 
                  ? "Perfect score! Amazing work!" 
                  : score >= questions.length / 2 
                  ? "Good job! Keep practicing." 
                  : "Keep practicing to improve."}
              </p>
            </div>
            
            {earnedBadges.length > 0 && (
              <div className="mb-8">
                <h3 className="text-xl font-semibold mb-4">New Badges Earned!</h3>
                <div className="flex flex-wrap justify-center gap-4">
                  {earnedBadges.map(badge => (
                    <BadgeDisplay key={badge.id} badge={badge} size="md" showDetails />
                  ))}
                </div>
              </div>
            )}
            
            <div className="flex justify-center gap-4">
              <Button 
                onClick={handleRetakeQuiz}
                className="bg-gradient-to-r from-neon-cyan to-neon-blue"
              >
                Retake Quiz
              </Button>
              <Button variant="outline" asChild>
                <Link to={`/deck/${deck.id}`}>
                  Return to Deck
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/leaderboard">
                  View Leaderboard
                </Link>
              </Button>
            </div>
          </div>
        ) : (
          <div className="mb-8">
            {currentQuestion && (
              <QuizCard 
                question={currentQuestion}
                onAnswer={handleAnswer}
              />
            )}
          </div>
        )}
      </main>
    </div>
  );
}
