
export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  deckId: string;
}

export interface QuizResult {
  id: string;
  userId: string;
  deckId: string;
  score: number;
  totalQuestions: number;
  date: number;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: string;
  earnedAt?: number;
}
