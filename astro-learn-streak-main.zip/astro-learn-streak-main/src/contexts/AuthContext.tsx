
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { toast } from "sonner";

interface User {
  id: string;
  name: string;
  email: string;
}

interface AuthContextType {
  currentUser: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from localStorage on initial render
  useEffect(() => {
    const storedUser = localStorage.getItem("flashcardUser");
    if (storedUser) {
      try {
        setCurrentUser(JSON.parse(storedUser));
      } catch (error) {
        console.error("Failed to parse user from localStorage", error);
      }
    }
    setIsLoading(false);
  }, []);

  // Mock authentication functions (would connect to backend in a real app)
  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock validation
      if (email === "demo@example.com" && password === "password") {
        const user = {
          id: "user-1",
          name: "Demo User",
          email: "demo@example.com",
        };
        setCurrentUser(user);
        localStorage.setItem("flashcardUser", JSON.stringify(user));
        toast.success("Login successful!");
        return true;
      } else {
        // Check if user exists in localStorage (for registered users)
        const registeredUsers = JSON.parse(localStorage.getItem("registeredUsers") || "[]");
        const foundUser = registeredUsers.find((user: any) => 
          user.email === email && user.password === password
        );
        
        if (foundUser) {
          const user = {
            id: foundUser.id,
            name: foundUser.name,
            email: foundUser.email,
          };
          setCurrentUser(user);
          localStorage.setItem("flashcardUser", JSON.stringify(user));
          toast.success("Login successful!");
          return true;
        } else {
          toast.error("Invalid email or password");
          return false;
        }
      }
    } catch (error) {
      console.error("Login error:", error);
      toast.error("Login failed. Please try again.");
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Check if email is already registered
      const registeredUsers = JSON.parse(localStorage.getItem("registeredUsers") || "[]");
      if (registeredUsers.some((user: any) => user.email === email)) {
        toast.error("This email is already registered");
        return false;
      }
      
      // Create new user
      const newUser = {
        id: `user-${Date.now()}`,
        name,
        email,
        password, // In a real app, never store plain text passwords
      };
      
      // Save to localStorage
      registeredUsers.push(newUser);
      localStorage.setItem("registeredUsers", JSON.stringify(registeredUsers));
      
      // Auto login after registration
      const user = {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
      };
      setCurrentUser(user);
      localStorage.setItem("flashcardUser", JSON.stringify(user));
      
      toast.success("Registration successful!");
      return true;
    } catch (error) {
      console.error("Registration error:", error);
      toast.error("Registration failed. Please try again.");
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("flashcardUser");
    toast.info("Logged out successfully");
  };

  const value = {
    currentUser,
    login,
    register,
    logout,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
