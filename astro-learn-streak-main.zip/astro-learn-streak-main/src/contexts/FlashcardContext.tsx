import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { toast } from "sonner";
import { QuizQuestion, QuizResult, Badge } from "@/types/quiz";

// Define types
export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  lastReviewed: number | null; // timestamp
  correctCount: number;
  incorrectCount: number;
  deckId: string;
}

export interface Deck {
  id: string;
  name: string;
  description: string;
  userId: string;
  createdAt: number;
  lastStudied: number | null;
  color: string;
}

export interface StudySession {
  id: string;
  deckId: string;
  date: number;
  cardsStudied: number;
  correctAnswers: number;
  incorrectAnswers: number;
}

interface FlashcardContextType {
  decks: Deck[];
  flashcards: Flashcard[];
  sessions: StudySession[];
  streak: number;
  quizzes: QuizQuestion[];
  quizResults: QuizResult[];
  badges: Badge[];
  createDeck: (deck: Omit<Deck, "id" | "createdAt">) => string;
  updateDeck: (deck: Deck) => void;
  deleteDeck: (deckId: string) => void;
  createFlashcard: (flashcard: Omit<Flashcard, "id" | "lastReviewed" | "correctCount" | "incorrectCount">) => string;
  updateFlashcard: (flashcard: Flashcard) => void;
  deleteFlashcard: (flashcardId: string) => void;
  getFlashcardsByDeck: (deckId: string) => Flashcard[];
  recordStudySession: (session: Omit<StudySession, "id" | "date">) => void;
  markCardResult: (cardId: string, isCorrect: boolean) => void;
  refreshStreak: () => void;
  lastActivity: number | null;
  createQuiz: (deckId: string) => QuizQuestion[];
  saveQuizResult: (result: Omit<QuizResult, "id" | "date">) => void;
  getQuizzesByDeck: (deckId: string) => QuizQuestion[];
  checkAndAwardBadges: (userId: string) => Badge[];
  getUserBadges: (userId: string) => Badge[];
  getLeaderboard: () => { userId: string; score: number; badges: number }[];
}

const FlashcardContext = createContext<FlashcardContextType | null>(null);

export function useFlashcards() {
  const context = useContext(FlashcardContext);
  if (!context) {
    throw new Error("useFlashcards must be used within a FlashcardProvider");
  }
  return context;
}

interface FlashcardProviderProps {
  children: ReactNode;
  userId?: string;
}

export function FlashcardProvider({ children, userId }: FlashcardProviderProps) {
  const [decks, setDecks] = useState<Deck[]>([]);
  const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [streak, setStreak] = useState<number>(0);
  const [lastActivity, setLastActivity] = useState<number | null>(null);
  const [quizzes, setQuizzes] = useState<QuizQuestion[]>([]);
  const [quizResults, setQuizResults] = useState<QuizResult[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);

  // Default badges
  const defaultBadges: Badge[] = [
    {
      id: "badge-first-quiz",
      name: "Quiz Novice",
      description: "Completed your first quiz",
      icon: "badge",
      condition: "firstQuiz"
    },
    {
      id: "badge-perfect-score",
      name: "Perfect Score",
      description: "Achieved 100% on a quiz",
      icon: "badge-check",
      condition: "perfectScore"
    },
    {
      id: "badge-streak-3",
      name: "Consistent Learner",
      description: "Maintained a 3-day streak",
      icon: "badge-alert",
      condition: "streak3"
    },
    {
      id: "badge-master",
      name: "Deck Master",
      description: "Completed all cards in a deck with 90% accuracy",
      icon: "award",
      condition: "deckMaster"
    },
    {
      id: "badge-quiz-5",
      name: "Quiz Champion",
      description: "Completed 5 quizzes",
      icon: "badge-info",
      condition: "quiz5"
    }
  ];

  // Load data from localStorage on initial render
  useEffect(() => {
    if (userId) {
      loadData(userId);
      refreshStreak();
    } else {
      // Clear data when no user is logged in
      setDecks([]);
      setFlashcards([]);
      setSessions([]);
      setStreak(0);
      setLastActivity(null);
      setQuizzes([]);
      setQuizResults([]);
      setBadges([]);
    }
  }, [userId]);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (userId && (decks.length > 0 || flashcards.length > 0 || sessions.length > 0 || quizResults.length > 0 || badges.length > 0)) {
      saveData(userId);
    }
  }, [decks, flashcards, sessions, userId, quizResults, badges]);

  const loadData = (userId: string) => {
    try {
      // Load decks
      const storedDecks = localStorage.getItem(`flashcards-decks-${userId}`);
      if (storedDecks) {
        setDecks(JSON.parse(storedDecks));
      }

      // Load flashcards
      const storedCards = localStorage.getItem(`flashcards-cards-${userId}`);
      if (storedCards) {
        setFlashcards(JSON.parse(storedCards));
      }

      // Load study sessions
      const storedSessions = localStorage.getItem(`flashcards-sessions-${userId}`);
      if (storedSessions) {
        setSessions(JSON.parse(storedSessions));
      }

      // Load streak and last activity
      const storedStreak = localStorage.getItem(`flashcards-streak-${userId}`);
      if (storedStreak) {
        setStreak(JSON.parse(storedStreak));
      }
      
      const storedActivity = localStorage.getItem(`flashcards-lastActivity-${userId}`);
      if (storedActivity) {
        setLastActivity(JSON.parse(storedActivity));
      }
      
      // Load quizzes
      const storedQuizzes = localStorage.getItem(`flashcards-quizzes-${userId}`);
      if (storedQuizzes) {
        setQuizzes(JSON.parse(storedQuizzes));
      }
      
      // Load quiz results
      const storedQuizResults = localStorage.getItem(`flashcards-quizResults-${userId}`);
      if (storedQuizResults) {
        setQuizResults(JSON.parse(storedQuizResults));
      }
      
      // Load badges or set default badges
      const storedBadges = localStorage.getItem(`flashcards-badges-${userId}`);
      if (storedBadges) {
        setBadges(JSON.parse(storedBadges));
      } else {
        setBadges(defaultBadges);
      }
    } catch (error) {
      console.error("Failed to load flashcard data", error);
      toast.error("Failed to load your flashcard data");
    }
  };

  const saveData = (userId: string) => {
    try {
      localStorage.setItem(`flashcards-decks-${userId}`, JSON.stringify(decks));
      localStorage.setItem(`flashcards-cards-${userId}`, JSON.stringify(flashcards));
      localStorage.setItem(`flashcards-sessions-${userId}`, JSON.stringify(sessions));
      localStorage.setItem(`flashcards-streak-${userId}`, JSON.stringify(streak));
      localStorage.setItem(`flashcards-lastActivity-${userId}`, JSON.stringify(lastActivity));
      localStorage.setItem(`flashcards-quizzes-${userId}`, JSON.stringify(quizzes));
      localStorage.setItem(`flashcards-quizResults-${userId}`, JSON.stringify(quizResults));
      localStorage.setItem(`flashcards-badges-${userId}`, JSON.stringify(badges));
    } catch (error) {
      console.error("Failed to save flashcard data", error);
      toast.error("Failed to save your changes");
    }
  };

  // CRUD operations for decks
  const createDeck = (newDeck: Omit<Deck, "id" | "createdAt">): string => {
    const id = `deck-${Date.now()}`;
    const deckWithId: Deck = {
      ...newDeck,
      id,
      createdAt: Date.now(),
      lastStudied: null
    };
    
    setDecks(prevDecks => [...prevDecks, deckWithId]);
    toast.success(`Deck "${newDeck.name}" created`);
    return id;
  };

  const updateDeck = (updatedDeck: Deck) => {
    setDecks(prevDecks => 
      prevDecks.map(deck => deck.id === updatedDeck.id ? updatedDeck : deck)
    );
    toast.success(`Deck "${updatedDeck.name}" updated`);
  };

  const deleteDeck = (deckId: string) => {
    // Delete associated flashcards first
    setFlashcards(prevCards => prevCards.filter(card => card.deckId !== deckId));
    
    // Delete the deck
    setDecks(prevDecks => {
      const deckToDelete = prevDecks.find(deck => deck.id === deckId);
      const newDecks = prevDecks.filter(deck => deck.id !== deckId);
      if (deckToDelete) {
        toast.success(`Deck "${deckToDelete.name}" deleted`);
      }
      return newDecks;
    });
  };

  // CRUD operations for flashcards
  const createFlashcard = (newCard: Omit<Flashcard, "id" | "lastReviewed" | "correctCount" | "incorrectCount">): string => {
    const id = `card-${Date.now()}`;
    const cardWithId: Flashcard = {
      ...newCard,
      id,
      lastReviewed: null,
      correctCount: 0,
      incorrectCount: 0
    };
    
    setFlashcards(prevCards => [...prevCards, cardWithId]);
    return id;
  };

  const updateFlashcard = (updatedCard: Flashcard) => {
    setFlashcards(prevCards => 
      prevCards.map(card => card.id === updatedCard.id ? updatedCard : card)
    );
  };

  const deleteFlashcard = (cardId: string) => {
    setFlashcards(prevCards => prevCards.filter(card => card.id !== cardId));
    toast.success("Flashcard deleted");
  };

  const getFlashcardsByDeck = (deckId: string): Flashcard[] => {
    return flashcards.filter(card => card.deckId === deckId);
  };

  // Study session management
  const recordStudySession = (sessionData: Omit<StudySession, "id" | "date">) => {
    const now = Date.now();
    const newSession: StudySession = {
      ...sessionData,
      id: `session-${now}`,
      date: now
    };
    
    setSessions(prevSessions => [...prevSessions, newSession]);
    
    // Update deck's last studied timestamp
    setDecks(prevDecks => 
      prevDecks.map(deck => 
        deck.id === sessionData.deckId 
          ? { ...deck, lastStudied: now }
          : deck
      )
    );
    
    // Update last activity and streak
    setLastActivity(now);
    refreshStreak();
    
    toast.success("Study session recorded!");
  };

  const markCardResult = (cardId: string, isCorrect: boolean) => {
    setFlashcards(prevCards => 
      prevCards.map(card => {
        if (card.id === cardId) {
          return {
            ...card,
            lastReviewed: Date.now(),
            correctCount: isCorrect ? card.correctCount + 1 : card.correctCount,
            incorrectCount: isCorrect ? card.incorrectCount : card.incorrectCount + 1
          };
        }
        return card;
      })
    );
  };

  // Streak management
  const refreshStreak = () => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const today = now.getTime();
    
    const yesterday = today - 86400000; // 24 hours in milliseconds
    
    if (!lastActivity) {
      // First activity
      setStreak(1);
      setLastActivity(Date.now());
      return;
    }
    
    const lastActivityDate = new Date(lastActivity);
    lastActivityDate.setHours(0, 0, 0, 0);
    const lastActivityDay = lastActivityDate.getTime();
    
    if (lastActivityDay === today) {
      // Already recorded today's activity
      return;
    } else if (lastActivityDay === yesterday) {
      // Consecutive day
      setStreak(prevStreak => prevStreak + 1);
      toast.success(`🔥 ${streak + 1} day streak! Keep it up!`);
    } else if (lastActivityDay < yesterday) {
      // Streak broken
      setStreak(1);
      toast.info("New streak started! Study daily to build it up.");
    }
    
    setLastActivity(Date.now());
  };

  // Quiz system functions
  const createQuiz = (deckId: string): QuizQuestion[] => {
    const deckCards = flashcards.filter(card => card.deckId === deckId);
    
    if (deckCards.length < 4) {
      toast.error("Need at least 4 cards in the deck to create a quiz");
      return [];
    }
    
    // Shuffle cards and take up to 10 for the quiz
    const shuffled = [...deckCards].sort(() => Math.random() - 0.5);
    const quizCards = shuffled.slice(0, Math.min(10, shuffled.length));
    
    // Generate quiz questions
    const questions = quizCards.map(card => {
      // Get 3 random incorrect options from other cards
      const otherCards = deckCards.filter(c => c.id !== card.id)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);
      
      const options = [
        card.answer,
        ...otherCards.map(c => c.answer)
      ].sort(() => Math.random() - 0.5);
      
      return {
        id: `quiz-q-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        question: card.question,
        options,
        correctAnswer: card.answer,
        deckId
      };
    });
    
    // Save quiz questions
    setQuizzes(prev => [...prev, ...questions]);
    
    return questions;
  };
  
  const saveQuizResult = (result: Omit<QuizResult, "id" | "date">) => {
    const newResult: QuizResult = {
      ...result,
      id: `quiz-result-${Date.now()}`,
      date: Date.now()
    };
    
    setQuizResults(prev => [...prev, newResult]);
    setLastActivity(Date.now());
    
    // Check for badges to award
    if (userId) {
      checkAndAwardBadges(userId);
    }
    
    toast.success(`Quiz completed! Score: ${result.score}/${result.totalQuestions}`);
  };
  
  const getQuizzesByDeck = (deckId: string): QuizQuestion[] => {
    return quizzes.filter(quiz => quiz.deckId === deckId);
  };
  
  // Badge system functions
  const checkAndAwardBadges = (userId: string): Badge[] => {
    const userBadges = badges.filter(b => b.earnedAt !== undefined);
    const unearnedBadges = badges.filter(b => b.earnedAt === undefined);
    const newEarnedBadges: Badge[] = [];
    
    // Check each unearned badge
    unearnedBadges.forEach(badge => {
      let earned = false;
      
      switch (badge.condition) {
        case "firstQuiz":
          earned = quizResults.length > 0;
          break;
          
        case "perfectScore":
          earned = quizResults.some(r => r.score === r.totalQuestions && r.totalQuestions > 0);
          break;
          
        case "streak3":
          earned = streak >= 3;
          break;
          
        case "deckMaster":
          earned = decks.some(deck => {
            const deckCards = flashcards.filter(card => card.deckId === deck.id);
            if (deckCards.length === 0) return false;
            
            const reviewedCards = deckCards.filter(card => card.lastReviewed !== null);
            if (reviewedCards.length < deckCards.length) return false;
            
            const totalAttempts = reviewedCards.reduce((sum, card) => sum + card.correctCount + card.incorrectCount, 0);
            const correctAttempts = reviewedCards.reduce((sum, card) => sum + card.correctCount, 0);
            
            return totalAttempts > 0 && (correctAttempts / totalAttempts) >= 0.9;
          });
          break;
          
        case "quiz5":
          earned = quizResults.length >= 5;
          break;
      }
      
      if (earned) {
        const updatedBadge = { ...badge, earnedAt: Date.now() };
        newEarnedBadges.push(updatedBadge);
      }
    });
    
    if (newEarnedBadges.length > 0) {
      // Update badges state
      setBadges(prev => prev.map(b => {
        const foundBadge = newEarnedBadges.find(nb => nb.id === b.id);
        return foundBadge || b;
      }));
      
      // Show toast for each new badge
      newEarnedBadges.forEach(badge => {
        toast.success(`🏆 Badge earned: ${badge.name}!`);
      });
    }
    
    return newEarnedBadges;
  };
  
  const getUserBadges = (userId: string): Badge[] => {
    return badges.filter(badge => badge.earnedAt !== undefined);
  };
  
  // Leaderboard function
  const getLeaderboard = () => {
    // This is simplified as we don't have multiple users in this demo
    // In a real app, this would aggregate data from all users
    if (!userId) return [];
    
    return [{
      userId: userId,
      score: quizResults.reduce((sum, result) => sum + result.score, 0),
      badges: badges.filter(b => b.earnedAt !== undefined).length
    }];
  };

  const value = {
    decks,
    flashcards,
    sessions,
    streak,
    quizzes,
    quizResults,
    badges,
    createDeck,
    updateDeck,
    deleteDeck,
    createFlashcard,
    updateFlashcard,
    deleteFlashcard,
    getFlashcardsByDeck,
    recordStudySession,
    markCardResult,
    refreshStreak,
    lastActivity,
    createQuiz,
    saveQuizResult,
    getQuizzesByDeck,
    checkAndAwardBadges,
    getUserBadges,
    getLeaderboard
  };

  return <FlashcardContext.Provider value={value}>{children}</FlashcardContext.Provider>;
}
